URBAN CITY 3D — PROYECTO ANDROID PARA GOOGLE PLAY

Qué incluye
- Proyecto Android Studio (Kotlin + WebView).
- Tu juego HTML colocado en app/src/main/assets/index.html.
- Orientación horizontal e inmersiva.
- targetSdk/compileSdk 36 (requisito vigente para nuevas apps en Google Play desde 31-08-2026).

IMPORTANTE ANTES DE PUBLICAR
1. El juego carga Three.js y OrbitControls desde CDN (cdnjs.cloudflare.com y jsdelivr.net).
   Por eso, en esta primera versión necesita internet para iniciar el motor 3D.
   Conviene probarlo en varios Android y luego integrar las librerías localmente para modo sin conexión.
2. El proyecto fuente no es todavía un AAB firmado ni una publicación aprobada por Google.
3. El identificador de paquete es com.urbancity3d.game. Si deseas cambiarlo, hazlo ANTES de crear la app en Play Console.
4. Revisa el juego, privacidad, clasificación de contenido, público objetivo, capturas e icono antes de enviar.

CÓMO GENERAR EL AAB
- Instala Android Studio estable y el Android SDK Platform 36.
- Abre esta carpeta en Android Studio.
- Espera la sincronización de Gradle.
- Menú Build > Generate Signed Bundle / APK.
- Elige Android App Bundle.
- Crea y guarda de forma segura tu keystore y contraseñas.
- Selecciona release y genera el archivo .aab.

CÓMO SUBIRLO
- Entra a https://play.google.com/console/
- Registra tu cuenta de desarrollador (cuota única indicada por Google: US$25).
- Crea una app: Urban City 3D, juego, idioma Español.
- Completa ficha de tienda, política de privacidad, seguridad de datos, clasificación de contenido y demás declaraciones.
- Ve a Pruebas > Prueba cerrada, crea una versión y sube el .aab.
- En cuentas personales nuevas sujetas al requisito, reúne al menos 12 testers inscritos continuamente durante 14 días y solicita acceso a producción.
- Cuando Play Console habilite producción, crea la versión de producción, sube el AAB y envíala a revisión.

No compartas tu archivo keystore ni sus contraseñas.
La aprobación y publicación final dependen de Google Play.
